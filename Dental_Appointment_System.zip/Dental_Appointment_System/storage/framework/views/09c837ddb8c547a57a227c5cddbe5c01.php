

<?php $__env->startSection('title', 'Appointments - DentalCare'); ?>

<?php $__env->startSection('content'); ?>
<style>
  .container {
    padding: 40px 20px;
    max-width: 900px;
    margin: auto;
    color: #444444;
  }

  h1 {
    margin-bottom: 30px;
    color: #444444;
    text-align: center;
  }

  table {
    width: 100%;
    border-collapse: collapse;
    margin-top: 20px;
  }

  th, td {
    padding: 12px;
    border: 1px solid #ccc;
    text-align: left;
    color: #444444;
  }

  th {
    background-color: #3fbbc0;
    color: white;
  }

  .no-appointments {
    text-align: center;
    margin-top: 40px;
    color: #888;
    font-size: 1.1rem;
  }

  .btn {
    background-color: #3fbbc0;
    color: white;
    padding: 8px 16px;
    border: none;
    border-radius: 5px;
    text-decoration: none;
    font-weight: 500;
    transition: background-color 0.3s ease;
  }

  .btn:hover {
    background-color: #36a6a9;
  }

  .status-free {
    color: green;
  }

  .status-booked {
    color: red;
  }

  .status-break {
    color: orange;
  }
</style>

<div class="container">
 


  <?php if($appoint_details->isEmpty()): ?>
    <p class="no-appointments">No appointments found.</p>
  <?php else: ?>
    <table>
      <thead>
        <tr>
          <th>Patient</th>
          <th>Time</th>
          <th>Status</th>
          <th>Payment</th>
          <th>Dental Record</th>
          <th>edit</th>
          <th> delete</th>
        </tr>
      </thead>
      <tbody>
        <?php $__currentLoopData = $appoint_details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $appointment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<tr>
    <td><?php echo e($appointment->patient->Name ?? 'N/A'); ?></td>
   
   
    <td><?php echo e(\Carbon\Carbon::parse($appointment->Appointment_Time)->format('h:i A')); ?></td>
    <td><?php echo e(ucfirst($appointment->status)); ?></td>
    <td>
    <?php if($appointment->billing): ?>
    <?php echo e($appointment->billing->status); ?> 
<?php else: ?>
    Unpaid 
<?php endif; ?>
</td>
            <td><a href="<?php echo e(route('dental-records.index', $appointment->patient_id)); ?>" class="btn">View</a></td>
             
          <td><a href="<?php echo e(route('edit_patient_appointment', $appointment->id)); ?>" class="btn btn-warning">Edit</a></td>

          
          <td><form action="<?php echo e(route('destroy_patient_appointment', $appointment->id)); ?>" method="POST" style="display:inline;">
            <?php echo csrf_field(); ?>
            <?php echo method_field('DELETE'); ?>
            <button type="submit" class="btn btn-danger" onclick="return confirm('Are you sure you want to delete this appointment?');">Delete</button>
          </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>
    </table>
  <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('dentist_system.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\dentist_appointment_system\resources\views/dentist_system/see_all_appointment.blade.php ENDPATH**/ ?>