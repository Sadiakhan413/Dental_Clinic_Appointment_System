

<?php $__env->startSection('content'); ?>
<div class="container" style="max-width: 500px; margin: auto; padding: 20px;">
    <h2>Admin Login</h2>

    <?php if($errors->any()): ?>
        <div style="color:red;"><?php echo e($errors->first()); ?></div>
    <?php endif; ?>

    <form method="POST" action="<?php echo e(route('login_submit')); ?>">
        <?php echo csrf_field(); ?>
        <div>
        <label>Username:</label>
        <input type="text" name="username" required class="form-control"><br><br>
        </div>
        <div>
        <label>Password:</label>
        <input type="password" name="password" required class="form-control" ><br><br>
</div>
        <button type="submit" class="btn btn-primary">Login</button>
    </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dentist_system.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\dentist_appointment_system\resources\views/dentist_system/admin_login_page.blade.php ENDPATH**/ ?>