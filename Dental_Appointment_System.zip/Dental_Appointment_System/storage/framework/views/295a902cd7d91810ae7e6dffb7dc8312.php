

<?php $__env->startSection('title', 'Dentist Login'); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>Dentist Login</h1>

    <form action="<?php echo e(url('check_dentist_info')); ?>" method="POST">
        <?php echo csrf_field(); ?>

        <div>
            <label for="username">Username</label>
            <input type="text" id="username" name="username" required />
        </div>

        <div>
            <label for="password">Password</label>
            <input type="password" id="password" name="password" required />
        </div>

        <button type="submit" class="btn">Login</button>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dentist_system.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\dentist_appointment_system\resources\views/dentist_system/dentist_login_page.blade.php ENDPATH**/ ?>