<nav>
  <div>
    <div class="logo">MEDICIO</div>
    <ul>
      <li><a href="/home_page">HOME</a></li>
      <li><a href="#about">ABOUT</a></li>
      <li><a href="#">CONTACT</a></li>
    </ul>
  </div>
</nav>
<?php /**PATH E:\soft\Xamp\htdocs\Dental_Clinic_Appointment_System\resources\views/dentist_system/navbar.blade.php ENDPATH**/ ?>