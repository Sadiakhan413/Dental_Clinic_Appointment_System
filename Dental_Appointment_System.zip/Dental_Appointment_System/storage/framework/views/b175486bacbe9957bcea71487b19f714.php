

<?php $__env->startSection('title', 'All Availability Records'); ?>

<?php $__env->startSection('content'); ?>
<style>
  .container {
    padding: 40px 20px;
    max-width: 900px;
    margin: auto;
  }

  h2 {
    text-align: center;
    margin-bottom: 25px;
    color: #444444;
  }

  table {
    width: 100%;
    border-collapse: collapse;
    margin-top: 10px;
  }

  th, td {
    border: 1px solid #ccc;
    padding: 12px;
    text-align: center;
  }

  th {
    background-color: #3fbbc0;
    color: white;
  }

  tr:nth-child(even) {
    background-color: #f2f2f2;
  }

  .no-records {
    text-align: center;
    color: #888;
    font-style: italic;
  }
</style>

<div class="container">
    <h2>All Availability Records</h2>

    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Dentist Name</th>
                <th>Date</th>
                <th>Day of Week</th>
                <th>Start Time</th>
                <th>End Time</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $availabilities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $availability): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($availability->id); ?></td>
                    <td><?php echo e($availability->dentist->Name ?? 'N/A'); ?></td>
                    <td><?php echo e(\Carbon\Carbon::parse($availability->Date)->format('d-m-Y')); ?></td>
                    <td><?php echo e($availability->day_of_week); ?></td>
                    <td><?php echo e(\Carbon\Carbon::parse($availability->start_time)->format('h:i A')); ?></td>
                    <td><?php echo e(\Carbon\Carbon::parse($availability->end_time)->format('h:i A')); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="6" class="no-records">No availability records found.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dentist_system.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\dentist_appointment_system\resources\views/dentist_system/all_availibilities.blade.php ENDPATH**/ ?>