

<?php $__env->startSection('content'); ?>
<div class="container">
  <h2>Edit Appointment</h2>

  <form action="<?php echo e(route('update_patient_appointment', $appointment->id)); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>

    <div class="form-group">
      <label for="Appointment_Time">Time:</label>
      <input type="time" name="Appointment_Time" id="Appointment_Time"  value="<?php echo e($appointment->Appointment_Time); ?>" required class="form-control">
    </div>

    <div class="form-group">
      <label for="status">Status:</label>
      <select name="status" id="status" class="form-control" required>
        <option value="pending" <?php echo e($appointment->status == 'pending' ? 'selected' : ''); ?>>Pending</option>
        <option value="confirmed" <?php echo e($appointment->status == 'confirmed' ? 'selected' : ''); ?>>Confirmed</option>
        <option value="completed" <?php echo e($appointment->status == 'completed' ? 'selected' : ''); ?>>Completed</option>
        <option value="cancelled" <?php echo e($appointment->status == 'cancelled' ? 'selected' : ''); ?>>Cancelled</option>
      </select>
    </div>

    <button type="submit" class="btn btn-primary">Update</button>
  </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dentist_system.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\dentist_appointment_system\resources\views/dentist_system/edit_patient_appointment_page.blade.php ENDPATH**/ ?>