<nav>
  <div>
    <div class="logo">MEDICIO</div>
    <ul>
      <li><a href="/home_page">HOME</a></li>
      <li><a href="#about">ABOUT</a></li>
      <li><a href="#">CONTACT</a></li>
    </ul>
  </div>
</nav>
